from django.shortcuts import render
from datetime import datetime
#from django.http import #HttpResponse

# Create your views here.

def index(request):
    data={'name':'waseem','age':'23','phone':'777777777','Registration_Number':'131646'}
    return render(request,'App_1_L3/index.html',data)

def home(request):
    return render(request, 'home.html')

def filters_example(request):
    context = {
        'name': 'waseem ali abdullh ali alidrisi',
        'today': datetime.now(),
        'now': datetime.now(),
    }
    return render(request, 'filters_example.html', context)

def tags_example(request):
    context = {
        'user': {'is_authenticated': False, 'username': 'وسيم'},
        'products': [
            {'name': 'كتاب Django', 'price': 100},
            {'name': 'كتاب Python', 'price': 120},
            {'name': 'كتاب البرمجة', 'price': 80},
        ],
    }
    return render(request, 'tags_example.html', context)

def previous_lecture(request):
    context = {
        'courses': [
            {'name': 'هندسة برمجيات عملي', 'code': 'SWE401', 'active': True},
            {'name': 'قواعد بيانات', 'code': 'DB301', 'active': True},
            {'name': 'ذكاء اصطناعي', 'code': 'AI401', 'active': False},
        ],
    }
    return render(request, 'previous_lecture.html', context)
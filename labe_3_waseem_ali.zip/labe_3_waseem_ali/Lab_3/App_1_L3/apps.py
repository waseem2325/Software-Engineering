from django.apps import AppConfig


class App1L3Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'App_1_L3'

from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index'),
    path('', views.home, name='home'),
    path('filters/', views.filters_example, name='filters_example'),
    path('tags/', views.tags_example, name='tags_example'),
    path('previous-lecture/', views.previous_lecture, name='previous_lecture'),
]

